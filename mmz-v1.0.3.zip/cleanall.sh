#!/bin/bash


killall -9 afrmc_control afrmc_monitor afrmc_uart
rm -r /mmz/log
